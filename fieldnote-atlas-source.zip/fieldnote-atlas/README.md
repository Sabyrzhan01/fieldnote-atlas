# Fieldnote Atlas

**A visual field-research archive for the details that make a place feel like itself.** Collect observations, interview fragments, artifacts, and signals; keep their sources and tags attached; explore the evidence on a map.

![Fieldnote Atlas concept: editorial map-led research archive](docs/design-system.md)

## Run locally

Requirement: Python 3.11+ (no third-party packages are needed for the runnable edition).

```sh
python3 server.py
```

Open `http://127.0.0.1:8091/` for the localStorage mock-service edition. Open `http://127.0.0.1:8091/?api=1` for the frontend connected to the SQLite API. The API can be checked at `/api/health` and `/api/atlas`.

The current runnable API uses Python's SQLite DB-API so it can run offline with the system Python. The earlier FastAPI/SQLAlchemy implementation remains in `backend/app/` as the planned ORM-backed deployment architecture; it requires installing `backend/requirements.txt` when the package registry is available.

Optional frontend convenience commands, if `npm` is available:

```sh
npm run dev
npm test
npm run build
```

`npm run dev` delegates to the same dependency-free Python server. SQLite state is written to `fieldnote.db`; use `FIELDNOTE_DB_PATH` to choose another file.

## Project map
- `frontend/` — React, TypeScript, Vite; mock and API service implementations
- `backend/` — FastAPI; in-memory and SQLAlchemy repository modes
- `openapi.yaml` — frontend/backend contract
- `docs/` — product spec, brainstorm, design brief, test/process guidance, backlog, role briefs

## Workflow
This project follows the staged path in `docs/process.md`: mock-backed frontend → OpenAPI contract → in-memory backend → SQLite through SQLAlchemy → integrated frontend/backend. GitHub Issues become the canonical backlog when the project is connected to a GitHub repo. Create the `mvp`, `post-mvp`, and `user-test-bug` labels and import `docs/issues.md`.

Groomed MVP issue bodies are in `issues/mvp/`. Once signed in and connected to the intended GitHub repo, run `python3 scripts/import_github_issues.py` to create 14 `mvp` issues and the observed `user-test-bug` issue.

## Status
Runnable dependency-free edition is verified in Chrome. API checks passed for seed, create, invalid input, star, SQLite reconnect persistence, delete, and not-found. The browser walkthrough verified first render, search, starred filtering, local mock creation, and SQLite API-backed creation. Python/JS syntax checks and four repository unit tests pass. GitHub Issues have not been created: no Git remote or authenticated GitHub session is available in the current browser. Import `docs/issues.md` after connecting the project repo, then have QA complete and close the backlog.
