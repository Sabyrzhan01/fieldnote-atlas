"""Import groomed Markdown issues. Run `gh auth login` and set a GitHub remote first."""
from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
def gh(*args,check=True): return subprocess.run(['gh',*args],cwd=ROOT,check=check,text=True,capture_output=True)
def main():
    if not (ROOT/'.git').exists(): raise SystemExit('Run this in the cloned Git repository.')
    if gh('auth','status',check=False).returncode: raise SystemExit('Authenticate first: gh auth login')
    if gh('repo','view',check=False).returncode: raise SystemExit('Add/select a GitHub repository remote first.')
    for name,color,description in [('mvp','d93f0b','Required for MVP launch'),('post-mvp','c5def5','Planned after MVP'),('user-test-bug','b60205','Bug found during manual user testing')]:
        gh('label','create',name,'--color',color,'--description',description,'--force',check=False)
    for path in sorted((ROOT/'issues/mvp').glob('*.md')):
        title=path.stem.replace('-',' ').title()
        print('Creating:',title)
        gh('issue','create','--title',title,'--body-file',str(path),'--label','mvp')
    bug=ROOT/'docs/user-test-bugs.md'
    gh('issue','create','--title','Fix blank first load caused by frontend script syntax error','--body-file',str(bug),'--label','user-test-bug')
if __name__=='__main__': main()
